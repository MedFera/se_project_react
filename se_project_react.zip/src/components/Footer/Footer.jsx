import './Footer.css'

function Footer() {
  return (
    <div className='footer'>
        <div className='footer__name'>Medin Feratovic</div>
        <div className='footer__year'>2026</div>
    </div>
  );
}

export default Footer;

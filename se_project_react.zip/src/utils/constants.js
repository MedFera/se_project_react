const longitude = "40.7128"
const latitude = "74.0060"
const apiKey = "bb70dde03746a6ae0029aaf18268eafe"


//const requestString = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=imperial&appid=${APIkey}`

/*
fetch(`https://api.openweathermap.org/data/2.5/weather?lat=40.7128&lon=74.0060&units=imperial&appid=bb70dde03746a6ae0029aaf18268eafe`)
.then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.json(); // Parses the JSON body into a JavaScript object
  })
  .then(data => {
    console.log(data); // Use the data in your application
  })
  .catch(error => {
    console.error('Error:', error); // Handle any errors during the fetch operation
  });

  */